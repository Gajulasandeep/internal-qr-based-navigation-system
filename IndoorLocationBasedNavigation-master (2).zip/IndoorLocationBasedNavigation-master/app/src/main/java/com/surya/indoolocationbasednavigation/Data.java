package com.surya.indoolocationbasednavigation;

public class Data {
    String name,distance;


    public Data(String name) {
        this.name = name;

    }
}
